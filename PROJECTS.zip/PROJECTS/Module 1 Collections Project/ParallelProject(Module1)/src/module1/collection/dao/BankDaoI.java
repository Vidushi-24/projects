package module1.collection.dao;

import module1.collection.bean.BankBean;

public interface BankDaoI {

	public BankBean checkAccount(long accNo);

	public void setData(long accNo, BankBean bean);

}
