package com.bank.dao;

import com.bank.entity.BankDetails;

public interface BankDAOInterface {
	public   BankDetails getAccountById(int id);
	public   void createAccount(BankDetails bank);
	public   void showBalance(BankDetails bank);
	public  void Deposit(BankDetails bank);
	public void Withdraw(BankDetails bank);
	public void printTransactions(int id);
	public  void commitTransaction();
	public void beginTransaction();

}
